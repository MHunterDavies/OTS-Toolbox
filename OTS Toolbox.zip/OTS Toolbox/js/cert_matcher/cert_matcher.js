$(document).ready(function () {
    var storage = window.localStorage;

    if (storageCertValue == "" && storageKeyValue == "") {
        storage.setItem("cert_validator_cert_value", "");
        storage.setItem("cert_validator_key_value", "");
    }

    var storageCertValue = storage.getItem("cert_validator_cert_value");
    var storageKeyValue = storage.getItem("cert_validator_key_value");

    $("#match_input_cert").val(storageCertValue)
    $("#match_input_key").val(storageKeyValue)

    var previousCertText = $("#match_input_cert").val()
    var previousKeyText = $("#match_input_key").val()

    function certMatcherLogs(message) {
        var today = new Date();
        var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
        var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
        var logTime = "[" + date + " " + time + "] "
        console.log(logTime + message)
    }

    function matchCertificate() {
        previousCertText = $("#match_input_cert").val()
        previousKeyText = $("#match_input_key").val()
        /* Codes Returned
        if false:
            0 = Generic, undefined error (likely js sign error).
            1 = Cert inputs ballsed.
        if true:
            0 = Both certs match
            1 = Both certs don't match
        */
        try {
            var inputCert = previousCertText;
            var inputKey = previousKeyText;
            var isCsr = inputCert.includes("-----BEGIN CERTIFICATE REQUEST-----");
            var isPem = inputCert.includes("-----BEGIN CERTIFICATE-----");
            var isKey = inputKey.includes("-----BEGIN PRIVATE KEY-----");

            if (!(isKey) || !((isCsr) || (isPem))) {
                return [false, 1];
            }
            if (isCsr) {
                certParams = KJUR.asn1.csr.CSRUtil.getParam(inputCert);
                certPubKey = KEYUTIL.getKey(certParams.sbjpubkey);
                certJwk = KEYUTIL.getJWKFromKey(certPubKey);

                resultModulus = certJwk.n;
            } else if (isPem) {
                var pemObject = new X509();
                pemObject.readCertPEM(inputCert);
                pemParam = pemObject.getParam();
                pemPubKey = KEYUTIL.getKey(pemParam.sbjpubkey);
                pemJwk = KEYUTIL.getJWKFromKey(pemPubKey);

                resultModulus = pemJwk.n;
            }

            keyImport = KEYUTIL.getKey(inputKey);
            keyJwk = KEYUTIL.getJWKFromKey(keyImport);
            keyModulus = keyJwk.n;

            if (resultModulus === keyModulus) {
                return [true, 0];
            } else {
                return [true, 1];
            }
        } catch (err) {
            return [false, 0, err];
        }
    }

    function resultText(type, message) {
        if (type === "error") {
            $("#match_output_text").text(message);
            $("#match_output_text").css("color", "#ffcccb");
        }
        if (type === "success") {
            $("#match_output_text").text(message);
            $("#match_output_text").css("color", "#7CFC00");
        }
        if (type === "clear") {
            $("#match_output_text").text(message);
            $("#match_output_text").css("color", "#fff");
        }

    }

    function checkText(manualRun) {
        var storage = window.localStorage;

        var currentCertText = $("#match_input_cert").val();
        var currentKeyText = $("#match_input_key").val();

        storage.setItem("cert_validator_cert_value", currentCertText);
        storage.setItem("cert_validator_key_value", currentKeyText);

        if (((previousCertText != currentCertText || previousKeyText != currentKeyText) && currentCertText.length > 40 && currentKeyText.length > 40) || currentCertText.length > 40 && currentKeyText.length > 40 && manualRun == "run") {
            var matchInfo = matchCertificate();

            if (matchInfo[0]) {
                if (matchInfo[1] === 0) {
                    resultText("success", "The KEY issued the certificate.");
                    certMatcherLogs("The KEY issued the certificate.");
                }
                if (matchInfo[1] === 1) {
                    resultText("error", "The KEY didn't issue the certificate.");
                    certMatcherLogs("The KEY didn't issue the certificate.");
                }
            } else if (!(matchInfo[0])) {
                if (matchInfo[1] === 0) {
                    switch (matchInfo[2].name) {
                        case "URIError":
                            resultText("error", "Invalid certificate provided.");
                            certMatcherLogs("Invalid certificate provided.");
                            break
                        default:
                            resultText("error", "Wtf did you provide? Whatever it is... it legit broke this...");
                            certMatcherLogs("Wtf did you provide? Whatever it is... it legit broke this...");
                            console.error(matchInfo[2]);
                            break
                    }
                }
                if (matchInfo[1] === 1) {
                    resultText("error", "Nah them certs aint right. Check again yo.");
                    certMatcherLogs("Nah them certs aint right. Check again yo.");
                }
            }
        } else if (currentCertText == "" || currentKeyText == "") {
            previousCertText = $("#match_input_cert").val()
            previousKeyText = $("#match_input_key").val()
            resultText("clear", "Canny validate until both boxes have stuff!");
        }
    }
    resultText("clear", "Nothing yet!");

    $("#match_input_cert").keyup(checkText);
    $("#match_input_key").keyup(checkText);
    $("#match_input_cert").change(checkText);
    $("#match_input_key").change(checkText);

    checkText("run");

})
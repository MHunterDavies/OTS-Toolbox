window.onload = function () {
    var storage = window.localStorage;

    if (storage.getItem("activated") === "true") {
        $("#popup_toggle_notifier").css("background-color", "#7CFC00")
    } else if (storage.getItem("activated") === "false") {
        $("#popup_toggle_notifier").css("background-color", "#ffcccb")
    }

    $("#popup_toggle_notifier").click(function() {
        if (storage.getItem("activated") === "false") {
            chrome.runtime.sendMessage({
                recipient: "background",
                from: "popup",
                toggleNotifier: true
            })
            $("#popup_toggle_notifier").css("background-color", "#7CFC00")
        } else if (storage.getItem("activated") === "true") {
            chrome.runtime.sendMessage({
                recipient: "background",
                from: "popup",
                toggleNotifier: false
            })
            $("#popup_toggle_notifier").css("background-color", "#ffcccb")
        }
    })

    window.onstorage = function(e) {
        if (e.key === "activated" && e.newValue === "true") {
            $("#popup_toggle_notifier").css("background-color", "#7CFC00")
        } else if (e.key === "activated" && e.newValue === "false") {
            $("#popup_toggle_notifier").css("background-color", "#ffcccb")
        }
    }

}
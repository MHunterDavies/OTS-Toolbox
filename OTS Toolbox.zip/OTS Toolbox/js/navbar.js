$(function() {
    $(".navbar-div").load("/html/navbar.html");
});
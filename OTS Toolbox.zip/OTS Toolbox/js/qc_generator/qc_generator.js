const countries = ["Austria", "Belgium", "Bulgaria", "Croatia", "Cyprus", "Czech", "Denmark", "Estonia", "Finland", "France", "Gibraltar", "Germany", "Greece", "Hungary", "Iceland", "Ireland", "Italy", "Liechtenstein", "Latvia", "Lithuania", "Luxembourg", "Norway", "Malta", "Netherlands", "Poland", "Portugal", "Romania", "Slovakia", "Slovenia", "Spain", "Sweden", "United Kingdom"];

/*
var ncaData = ncaDataSet(country)

qcGenerator(qcType, rolesList, ncaData) 
*/
countries.forEach(country => $("#qcGen_country_selecter").append('<option value="' + country + '">' + country + '</option>'))

// --------------- Log Stuff --------------- //

function qcGenLogs(message) {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var logTime = "[" + date + " " + time + "] "
    console.log(logTime + message)
}

function showWait() {
    $("#qcGen_please_wait").css("display", "block");
    $("#qcGen_please_wait_text").css("display", "block");
};

function hideWait() {
    $("#qcGen_please_wait").css("display", "none");
    $("#qcGen_please_wait_text").css("display", "none");
};

$(document).ready(function () {
    var storage = window.localStorage;

    if (storage.getItem("generatedqcStatement") !== null) {
        $("#qcGen_generated_qcStatement").text(storage.getItem("generatedqcStatement"))
    }
    $("#qcGen_country_selecter").change(function () {

        var el = $(this);
        if (el.val() === "Pick Option") {
            $("#qcGen_roles").css("display", "none");
            $("#qcGen_type").css("display", "none");
            $("#qcGen_submit").css("display", "none");

            $("input[name='qcGen_roles']").prop("required", false);
            $("select[name='qcGen_type']").prop("required", false);
        } else {
            $("#qcGen_roles").css("display", "block");
            $("#qcGen_type").css("display", "block");
            $("#qcGen_submit").css("display", "block");

            $("input[name='qcGen_roles']").prop("required", true);
            $("select[name='qcGen_type']").prop("required", true);
        }
    });
    $("#qcGen_options_form").on("submit", function (e) {
        e.preventDefault();
        var result = {}
        var roles = []
        var storage = window.localStorage;

        function genqcStatement() {
            if ($("#qcGen_please_wait").css("display") === "block") {
                $.each($("#qcGen_options_form").serializeArray(), function () {
                    result[this.name] = this.value;
                });
                if ("qcGen_roles_aisp" in result) {
                    roles.push("AISP")
                }
                if ("qcGen_roles_pisp" in result) {
                    roles.push("PISP")
                }
                if ("qcGen_roles_cbpii" in result) {
                    roles.push("CBPII")
                }
                if ("qcGen_roles_aspsp" in result) {
                    roles.push("ASPSP")
                }
                var ncaData = ncaDataSet(result["qcGen_country_select"]);
                qcStatement = qcGenerator(result["qcGen_type"], roles, ncaData);
                if (qcStatement !== false) {
                    $("#qcGen_generated_qcStatement").val(qcStatement)
                    storage.setItem("generatedqcStatement", qcStatement)
                } else {
                    // ERROR STUFF
                }
            }
        }
        showWait();
        setTimeout(genqcStatement, 200);
        setTimeout(hideWait, 1000);
    });
    $("#qcGen_clear_values").click(function () {
        var confirmed = confirm("Are you sure you wish to clear?")
        if (confirmed == true) {
            storage.setItem("generatedqcStatement", "");
            $("#qcGen_generated_qcStatement").val("");
        }
    })
    $("#qcGen_copy_values").click(function () {
        var storage = window.localStorage;
        var qctext = storage.getItem("generatedqcStatement");

        navigator.clipboard.writeText(qctext).then(function () {
            certMakerLogs("Copied to clipboard.");
            $("#qcGen_copy_values_text").text("Copied!");
            $("#qcGen_copy_values_text").css("color", "#7CFC00");
            setTimeout(() => {
                $("#qcGen_copy_values_text").text("");
            }, 2000);
        }, function () {
            certMakerLogs("Failed to copy to clipboard.");
            $("#qcGen_copy_values_text").text("Failed to copy!");
            $("#qcGen_copy_values_text").css("color", "#ffcccb");
            setTimeout(() => {
                $("#qcGen_copy_values_text").text("");
            }, 2000);
        });
    })
});
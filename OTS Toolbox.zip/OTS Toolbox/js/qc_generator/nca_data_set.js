function ncaDataSet (country) {
    switch (country) {
        case "Austria":
            return ["AT-FMA", "Austria Financial Market Authority"]
        case "Belgium":
            return ["BE-NBB", "National Bank of Belgium"]
        case "Bulgaria":
            return ["BG-BNB", "Bulgarian National Bank"]
        case "Croatia":
            return ["HR-CNB", "Croatian National Bank"]
        case "Cyprus":
            return ["CY-CBC", "Central Bank of Cyprus"]
        case "Czech":
            return ["CZ-CNB", "Czech National Bank"]
        case "Denmark":
            return ["DK-DFSA", "Danish Financial Supervisory Authority"]
        case "Estonia":
            return ["EE-FI", "Estonia Financial Supervisory Authority"]
        case "Finland":
            return ["FI-FINFSA", "Finnish Financial Supervisory Authority"]
        case "France":
            return ["FR-ACPR", "Prudential Supervisory and Resolution Authority"]
        case "Gibraltar":
            return ["GI-FSC", "Financial Services Commission"]
        case "Germany":
            return ["DE-BAFIN", "Federal Financial Supervisory Authority"]
        case "Greece":
            return ["GR-BOG", "Bank of Greece"]
        case "Hungary":
            return ["HU-CBH", "Central Bank of Hungary"]
        case "Iceland":
            return ["IS-FME", "Financial Supervisory Authority"]
        case "Ireland":
            return ["IE-CBI", "Central Bank of Ireland"]
        case "Italy":
            return ["IT-BI", "Bank of Italy"]
        case "Liechtenstein":
            return ["LI-FMA", "Financial Market Authority Liechtenstein"]
        case "Latvia":
            return ["LV-FCMC", "Financial and Capital Markets Commission"]
        case "Lithuania":
            return ["LT-BL", "Bank of Lithuania"]
        case "Luxembourg":
            return ["LU-CSSF", "Commission for the Supervision of Financial Sector"]
        case "Norway":
            return ["NO-FSA", "The Financial Supervisory Authority of Norway"]
        case "Malta":
            return ["MT-MFSA", "Malta Financial Services Authority"]
        case "Netherlands":
            return ["NL-DNB", "The Netherlands Bank"]
        case "Poland":
            return ["PL-PFSA", "Polish Financial Supervision Authority"]
        case "Portugal":
            return ["PT-BP", "Bank of Portugal"]
        case "Romania":
            return ["RO-NBR", "National Bank of Romania"]
        case "Slovakia":
            return ["SK-NBS", "National Bank of Slovakia"]
        case "Slovenia":
            return ["SI-BS", "Bank of Slovenia"]
        case "Spain":
            return ["ES-BE", "Bank of Spain"]
        case "Sweden":
            return ["SE-FINA", "Swedish Financial Supervision Authority"]
        case "United Kingdom":
            return ["GB-FCA", "Financial Conduct Authority"]
    }
}
function qcGenerator(qcType, rolesList, ncaData) {
    const
        qcTypeSeal = "0.4.0.1862.1.6.2",
        qcTypeWeb = "0.4.0.1862.1.6.3";

    var rolesSequence = []

    var etsiCode = ncaData[0]
    var ncaAuthority = ncaData[1]

    const
        roleAisp = {
            "seq": [{
                    "oid": "0.4.0.19495.1.3"
                },
                {
                    "utf8str": "PSP_AI"
                }
            ]
        },
        rolePisp = {
            "seq": [{
                    "oid": "0.4.0.19495.1.2"
                },
                {
                    "utf8str": "PSP_PI"
                }
            ]
        },
        roleAspsp = {
            "seq": [{
                    "oid": "0.4.0.19495.1.1"
                },
                {
                    "utf8str": "PSP_AS"
                }
            ]
        },
        roleCbpii = {
            "seq": [{
                    "oid": "0.4.0.19495.1.4"
                },
                {
                    "utf8str": "PSP_IC"
                }
            ]
        };

    switch (qcType) {
        case "Web":
            qcType = qcTypeWeb
            break
        case "Seal":
            qcType = qcTypeSeal
            break
    }

    rolesList.forEach(function (rolesIter) {
        if (rolesIter == "ASPSP") {
            rolesSequence.push(roleAspsp)
        }
        if (rolesIter == "CBPII") {
            rolesSequence.push(roleCbpii)
        }
        if (rolesIter == "AISP") {
            rolesSequence.push(roleAisp)
        }
        if (rolesIter == "PISP") {
            rolesSequence.push(rolePisp)
        }
    })

    var qcStatement = KJUR.asn1.ASN1Util.newObject({
        "seq": [{
                "seq": [{
                        "oid": "0.4.0.1862.1.6"
                    },
                    {
                        "seq": [{
                            "oid": qcType
                        }]
                    }
                ]
            },
            {
                "seq": [{
                        "oid": "0.4.0.19495.2"
                    },
                    {
                        "seq": [{
                                "seq": rolesSequence
                            },
                            {
                                "utf8str": ncaAuthority
                            },
                            {
                                "utf8str": etsiCode
                            }
                        ]
                    }
                ]
            }
        ]
    }).getEncodedHex();

    return qcStatement
}
// --------------- Log Stuff --------------- //

function certMakerLogs(message) {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var logTime = "[" + date + " " + time + "] "
    console.log(logTime + message)
}

function showWait() {
    $("#cert_please_wait").css("display", "block");
    $("#cert_please_wait_text").css("display", "block");
};

function hideWait() {
    $("#cert_please_wait").css("display", "none");
    $("#cert_please_wait_text").css("display", "none");
};

$(document).ready(function () {
    var storage = window.localStorage;

    if (storage.getItem("generatedCsr") !== null && storage.getItem("generatedKey") !== null) {
        $("#cert_generated_csr").text(storage.getItem("generatedCsr"))
        $("#cert_generated_key").text(storage.getItem("generatedKey"))
    }
    $("#cert_types").change(function () {

        var el = $(this);
        if (el.val() === "Pick Option") {
            $("#cert_roles").css("display", "none");
            $("#cert_org_name").css("display", "none");
            $("#cert_etsi_id").css("display", "none");
            $("#cert_ss_id").css("display", "none");
            $("#cert_org_id").css("display", "none");
            $("#cert_submit").css("display", "none");

            $("input[name='cert_roles']").prop("required", false);
            $("input[name='cert_org_name']").prop("required", false);
            $("input[name='cert_etsi_id']").prop("required", false);
            $("input[name='cert_ss_id']").prop("required", false);
            $("input[name='cert_org_id']").prop("required", false);
        } else {
            if (el.val() === "OBWAC" || el.val() === "OBSeal") {
                $("#cert_roles").css("display", "block");
                $("#cert_org_name").css("display", "block");
                $("#cert_etsi_id").css("display", "block");
                $("#cert_ss_id").css("display", "none");

                $("input[name='cert_roles']").prop("required", true);
                $("input[name='cert_org_name']").prop("required", true);
                $("input[name='cert_etsi_id']").prop("required", true);
                $("input[name='cert_ss_id']").prop("required", false);
            } else if (el.val() === "OBTransport" || el.val() === "OBSigning") {
                $("#cert_roles").css("display", "none");
                $("#cert_org_name").css("display", "none");
                $("#cert_etsi_id").css("display", "none");
                $("#cert_ss_id").css("display", "block");

                $("input[name='cert_roles']").prop("required", false);
                $("input[name='cert_org_name']").prop("required", false);
                $("input[name='cert_etsi_id']").prop("required", false);
                $("input[name='cert_ss_id']").prop("required", true);
            }
            $("#cert_org_id").css("display", "block");
            $("#cert_submit").css("display", "block");
            $("input[name='cert_org_id']").prop("required", true);
        }
    });
    $("#cert_options_form").on("submit", function (e) {
        e.preventDefault();
        var result = {}
        var roles = []
        var storage = window.localStorage;

        function genCerts() {
            if ($("#cert_please_wait").css("display") === "block") {
                $.each($("#cert_options_form").serializeArray(), function () {
                    result[this.name] = this.value;
                });
                if ("cert_roles_aisp" in result) {
                    roles.push("AISP")
                }
                if ("cert_roles_pisp" in result) {
                    roles.push("PISP")
                }
                if ("cert_roles_cbpii" in result) {
                    roles.push("CBPII")
                }
                if ("cert_roles_aspsp" in result) {
                    roles.push("ASPSP")
                }
                certs = generate(result["cert_type"], result["cert_org_name"], result["cert_etsi_id"], result["cert_org_id"], result["cert_ss_id"], roles);
                if (certs.length === 2) {
                    $("#cert_generated_csr").val(certs[0])
                    $("#cert_generated_key").val(certs[1])
                    storage.setItem("generatedCsr", certs[0])
                    storage.setItem("generatedKey", certs[1])
                    storage.setItem("lastcerttype", result["cert_type"])
                } else {
                    // ERROR STUFF
                }
            }
        }
        showWait();
        setTimeout(genCerts, 200);
        setTimeout(hideWait, 1000);
    });
    $("#cert_generated_match").on("click", function () { // This is currently disabled.
        showWait();
        setTimeout(hideWait, 200);
    });
    $("#cert_save_csr_button").click(function () {
        var storage = window.localStorage;
        var csrtext = storage.getItem("generatedCsr");
        var data = new Blob([csrtext], {
            type: 'text/plain'
        });
        var url = window.URL.createObjectURL(data);

        $("#cert_save_csr_a").prop("href", url)
        if (storage.getItem("lastcerttype") === "OBWAC") {
            $("#cert_save_csr_a").prop("download", "OBWAC.csr")
        } else if (storage.getItem("lastcerttype") === "OBSeal") {
            $("#cert_save_csr_a").prop("download", "OBSeal.csr")
        } else if (storage.getItem("lastcerttype") === "OBTransport") {
            $("#cert_save_csr_a").prop("download", "OBTransport.csr")
        } else if (storage.getItem("lastcerttype") === "OBSigning") {
            $("#cert_save_csr_a").prop("download", "OBSigning.csr")
        } else {
            $("#cert_save_csr_a").prop("download", "UNKNOWN.csr")
        }
    })
    $("#cert_save_key_button").click(function () {
        var storage = window.localStorage;
        var keytext = storage.getItem("generatedKey");
        var data = new Blob([keytext], {
            type: 'text/plain'
        });
        var url = window.URL.createObjectURL(data);

        $("#cert_save_key_a").prop("href", url)
        if (storage.getItem("lastcerttype") === "OBWAC") {
            $("#cert_save_key_a").prop("download", "OBWAC.key")
        } else if (storage.getItem("lastcerttype") === "OBSeal") {
            $("#cert_save_key_a").prop("download", "OBSeal.key")
        } else if (storage.getItem("lastcerttype") === "OBTransport") {
            $("#cert_save_key_a").prop("download", "OBTransport.key")
        } else if (storage.getItem("lastcerttype") === "OBSigning") {
            $("#cert_save_key_a").prop("download", "OBSigning.key")
        } else {
            $("#cert_save_key_a").prop("download", "UNKNOWN.key")
        }
    })
    $("#cert_clear_values").click(function () {
        var confirmed = confirm("Are you sure you wish to clear the values?")
        if (confirmed == true) {
            storage.setItem("generatedCsr", "");
            storage.setItem("generatedKey", "");
            $("#cert_generated_csr").val("");
            $("#cert_generated_key").val("");
        }
    })
    $("#cert_copy_values").click(function () {
        var storage = window.localStorage;
        var csrtext = storage.getItem("generatedCsr");
        var keytext = storage.getItem("generatedKey");

        navigator.clipboard.writeText(csrtext + keytext).then(function () {
            certMakerLogs("Copied to clipboard.");
            $("#cert_copy_values_text").text("Copied!");
            $("#cert_copy_values_text").css("color", "#7CFC00");
            setTimeout(() => {
                $("#cert_copy_values_text").text("");
            }, 2000);
        }, function () {
            certMakerLogs("Failed to copy to clipboard.");
            $("#cert_copy_values_text").text("Failed to copy!");
            $("#cert_copy_values_text").css("color", "#ffcccb");
            setTimeout(() => {
                $("#cert_copy_values_text").text("");
            }, 2000);
        });
    })
});
function generate(certType, orgName, orgIdentifier, orgID, ssID, rolesList) {
    var date = new Date()

    const
        qcTypeSeal = "0.4.0.1862.1.6.2",
        qcTypeWeb = "0.4.0.1862.1.6.3";

    var keyUsageNames = []

    var rolesSequence = []

    const
        roleAisp = {
            "seq": [{
                    "oid": "0.4.0.19495.1.3"
                },
                {
                    "utf8str": "PSP_AI"
                }
            ]
        },
        rolePisp = {
            "seq": [{
                    "oid": "0.4.0.19495.1.2"
                },
                {
                    "utf8str": "PSP_PI"
                }
            ]
        },
        roleAspsp = {
            "seq": [{
                    "oid": "0.4.0.19495.1.1"
                },
                {
                    "utf8str": "PSP_AS"
                }
            ]
        },
        roleCbpii = {
            "seq": [{
                    "oid": "0.4.0.19495.1.4"
                },
                {
                    "utf8str": "PSP_IC"
                }
            ]
        };

    const extKeyUsage = {
        "extname": "extKeyUsage",
        "array": [
            "clientAuth",
            "serverAuth"
        ]
    }

    var privateKey = KEYUTIL.generateKeypair("RSA", 2048)
    var privateKeyGen = KEYUTIL.getPEM(privateKey.prvKeyObj, "PKCS8PRV")

    new KJUR.asn1.DERObjectIdentifier({
        "name": "organizationIdentifier",
        "oid": "2.5.4.97"
    })

    var csrGenVars = {
        "subject": {},
        "sbjpubkey": privateKey.pubKeyObj,
        "extreq": null,
        "sigalg": "SHA256withRSA",
        "sbjprvkey": privateKey.prvKeyObj
    }

    if (certType == "OBWAC" || certType == "OBSeal") {
        var subjectDN = "/C=GB/O=" + orgName + "/organizationIdentifier=" + orgIdentifier + "/CN=" + orgID
        csrGenVars["subject"] = {
            "str": subjectDN
        }

        var extReq = []

        if (certType == "OBWAC") {
            keyUsageNames.push("digitalSignature")
            keyUsage = {
                "extname": "keyUsage",
                "critical": true,
                "names": keyUsageNames
            }
            extReq.push(keyUsage)
            extReq.push(extKeyUsage)
            qcType = qcTypeWeb
        } else if (certType == "OBSeal") {
            keyUsageNames.push("digitalSignature", "nonRepudiation")
            keyUsage = {
                "extname": "keyUsage",
                "critical": true,
                "names": keyUsageNames
            }
            extReq.push(keyUsage)
            qcType = qcTypeSeal
        }

        rolesList.forEach(function (rolesIter) {
            if (rolesIter == "ASPSP") {
                rolesSequence.push(roleAspsp)
            }
            if (rolesIter == "CBPII") {
                rolesSequence.push(roleCbpii)
            }
            if (rolesIter == "AISP") {
                rolesSequence.push(roleAisp)
            }
            if (rolesIter == "PISP") {
                rolesSequence.push(rolePisp)
            }
        })

        var qcStatement = KJUR.asn1.ASN1Util.newObject({
            "seq": [{
                    "seq": [{
                            "oid": "0.4.0.1862.1.6"
                        },
                        {
                            "seq": [{
                                "oid": qcType
                            }]
                        }
                    ]
                },
                {
                    "seq": [{
                            "oid": "0.4.0.19495.2"
                        },
                        {
                            "seq": [{
                                    "seq": rolesSequence
                                },
                                {
                                    "utf8str": "Financial Conduct Authority"
                                },
                                {
                                    "utf8str": "GB-FCA"
                                }
                            ]
                        }
                    ]
                }
            ]
        }).getEncodedHex();

        subjectKeyIdentifier = {
            "extname": "subjectKeyIdentifier",
            "kid": privateKey.pubKeyObj
        }

        qcStatementExt = {
            "extname": "1.3.6.1.5.5.7.1.3",
            "extn": {
                "asn1": {
                    "tlv": qcStatement
                }
            }
        }

        extReq.push(subjectKeyIdentifier)
        extReq.push(qcStatementExt)

        csrGenVars["extreq"] = extReq
    }

    if (certType == "OBTransport" || certType == "OBSigning") {
        var subjectDN = "/C=GB/O=OpenBanking/OU=" + orgID + "/CN=" + ssID
        csrGenVars["subject"] = {
            "str": subjectDN
        }
    }

    var csrGen = new KJUR.asn1.csr.CertificationRequest(csrGenVars)
    csrGen = csrGen.getPEM()

    return [csrGen, privateKeyGen]
}

//generate("OBWAC", "éntrust", "TESTETSI", "TESTORGID", 0, ["AISP", "PISP"])